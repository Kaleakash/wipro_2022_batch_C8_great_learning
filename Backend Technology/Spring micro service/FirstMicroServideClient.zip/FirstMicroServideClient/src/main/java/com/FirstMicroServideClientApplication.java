package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstMicroServideClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstMicroServideClientApplication.class, args);
	}

}
